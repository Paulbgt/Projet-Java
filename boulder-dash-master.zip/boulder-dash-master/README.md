Boulder Dash
=====================

[![Build Status](https://travis-ci.org/valeriansaliou/boulder-dash.svg?branch=master)](https://travis-ci.org/valeriansaliou/boulder-dash)

Boulder Dash game, done in Java.

Use of the MVC pattern.